1. Praktikum 1 Membuat projek flutter Baru
    ![Hasil Praktikum 1](c:\Users\acer\Pictures\Saved Pictures\Screenshot 2024-09-24 065634.png)

2. praktikum 2 membuat repository GitHub dan laporan praktikum
    ![hasil praktikum 2](c:\Users\acer\Pictures\Saved Pictures\screenshot.jpg)

3. praktikum 3 menerapkan widget dasar
    ![langkah 1 text widget]

    ![langkah 2 image widget]

4. praktikum 4 menerapkan widget material design dan iOS cupertino
    ![langkah 1 cupertino button dan loading bar]

    ![langkah 2 floating action button (FAB)]

    ![langkah 3 scaffold widget]

    ![langkah 4 dialog widget]

    ![langkah 5 input dan selection widget]

    ![langkah 6 date and time pickers]
    